@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Stop DA3.ps1"
if errorlevel 1 pause
